"""Humanoid robot package."""
# Intentionally keep this file minimal to avoid heavy imports during test discovery.
__all__: list[str] = []
